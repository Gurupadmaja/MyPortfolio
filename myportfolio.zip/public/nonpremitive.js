arr=[1,2,3,4,5,6,7,8,8,10]
console.log(arr[4]);

fruits=["apple","banana","mango"];
fruits.push("grapes")
console.log(fruits)
fruits.unshift("Orange")
console.log(fruits)

nums=[10,20,30,40,50]
console.log(nums.includes(30));